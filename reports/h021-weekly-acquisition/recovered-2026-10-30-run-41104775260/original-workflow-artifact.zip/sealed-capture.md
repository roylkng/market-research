# H021 full U001 consensus capture — 2026-10-30

Research only. Live capital disabled. Return outcomes unopened.

## Capture identity

- Logical capture: `2026-10-30-full-u001-v1`
- Captured at UTC: `2026-10-30T18:17:51.323016+00:00`
- Source version: `H021-public-stockanalysis-spgi-plus-trendlyne-secondary-v1`
- Frozen universe blob: `8026e81faee3e913d2fba1dba72d60603b69fa07`
- Canonical payload SHA-256: `b48bd8ec00075e4d8fc74a1ec5a575d8f8f3c44b061c2f70fb8a12bc737842f4`

## Coverage

| State | Count |
|---|---:|
| IDENTITY_UNRESOLVED | 0 |
| NO_COVERAGE | 0 |
| OBSERVED | 0 |
| PARTIAL | 100 |
| SOURCE_BLOCKED | 0 |

Explicit consensus EPS: **99 / 100**
Primary EPS semantics complete: **99 / 99 EPS rows**

Analyst count >=5: **93**
Analyst count 2-4: **3**
Analyst count <2 or unavailable: **4**

## Frozen batches

- B01 ranks 1-50: 50 processed
- B02 ranks 51-100: 50 processed

No price, return, H013, H019, H020, PF001, valuation, or outcome input is part of this capture artifact.
